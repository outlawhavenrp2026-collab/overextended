# FearX-NpcMedic

THIS SCRIPT IS PROTECTED UNDER AGPL-3.0 license ANY CHANGES OR RE-RELEASES MUST BE CREDITED TOWARDS ME FOR THE ORIGINAL 
Preview : https://youtu.be/L1H5jwHxh6E

Features 

- Medic Command To Call Medic

- You Must be Dead To Call The Medic

- Can Pay With Cash Or Bank Can Disable Either One It Checks For Cash First

- Uses oxlib Noti And Progressbar

- Npc DeSpawns After Revived

- Can Config A Wait Time For When The Medic Comes Afer u Do Command 
